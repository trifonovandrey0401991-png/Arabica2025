
import 'package:flutter/material.dart';
import '../widgets/header.dart';
class StoresScreen extends StatelessWidget {
  const StoresScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: const Header('STORESSCREEN'), body: const Center(child: Text('STORESSCREEN', style: TextStyle(color: Colors.white, fontSize: 22))));
  }
}
