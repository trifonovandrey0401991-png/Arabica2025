
import 'package:flutter/material.dart';
import '../widgets/header.dart';
class AntiFraudScreen extends StatelessWidget {
  const AntiFraudScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: const Header('ANTIFRAUDSCREEN'), body: const Center(child: Text('ANTIFRAUDSCREEN', style: TextStyle(color: Colors.white, fontSize: 22))));
  }
}
