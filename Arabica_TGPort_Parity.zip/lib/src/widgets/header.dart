
import 'package:flutter/material.dart';
class Header extends StatelessWidget implements PreferredSizeWidget{
  final String title;
  const Header(this.title, {super.key});
  @override
  Size get preferredSize => const Size.fromHeight(56);
  @override
  Widget build(BuildContext context) {
    return AppBar(
      backgroundColor: Colors.black,
      elevation: 0,
      centerTitle: true,
      title: Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, letterSpacing: 1.5)),
    );
  }
}
