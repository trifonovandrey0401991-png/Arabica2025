
import 'package:flutter/material.dart';
import '../widgets/header.dart';
class StockScreen extends StatelessWidget {
  const StockScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: const Header('STOCKSCREEN'), body: const Center(child: Text('STOCKSCREEN', style: TextStyle(color: Colors.white, fontSize: 22))));
  }
}
