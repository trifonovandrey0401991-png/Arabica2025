
import 'package:flutter/material.dart';
import '../widgets/header.dart';
class AdminPanelScreen extends StatelessWidget {
  const AdminPanelScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: const Header('ADMINPANELSCREEN'), body: const Center(child: Text('ADMINPANELSCREEN', style: TextStyle(color: Colors.white, fontSize: 22))));
  }
}
