
import 'package:flutter/material.dart';
import '../widgets/header.dart';
class PhotoFlowScreen extends StatelessWidget {
  const PhotoFlowScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: const Header('PHOTOFLOWSCREEN'), body: const Center(child: Text('PHOTOFLOWSCREEN', style: TextStyle(color: Colors.white, fontSize: 22))));
  }
}
