
import 'package:flutter/material.dart';
import '../widgets/header.dart';
class ExpensesScreen extends StatelessWidget {
  const ExpensesScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: const Header('EXPENSESSCREEN'), body: const Center(child: Text('EXPENSESSCREEN', style: TextStyle(color: Colors.white, fontSize: 22))));
  }
}
