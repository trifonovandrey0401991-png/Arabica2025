
import 'package:flutter/material.dart';
import '../widgets/header.dart';
class UsersScreen extends StatelessWidget {
  const UsersScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: const Header('USERSSCREEN'), body: const Center(child: Text('USERSSCREEN', style: TextStyle(color: Colors.white, fontSize: 22))));
  }
}
