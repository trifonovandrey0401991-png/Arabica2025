
import 'package:flutter/material.dart';
import '../widgets/header.dart';
class RatingsScreen extends StatelessWidget {
  const RatingsScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: const Header('RATINGSSCREEN'), body: const Center(child: Text('RATINGSSCREEN', style: TextStyle(color: Colors.white, fontSize: 22))));
  }
}
