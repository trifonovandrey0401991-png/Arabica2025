
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../config.dart';
class Api {
  static Uri _u()=> Uri.parse(Config.backendUrl);
  static Map<String,String> _h()=> {'Content-Type':'application/json'};
  static Future<Map<String,dynamic>> call(String action, Map<String,dynamic> data) async {
    final body = jsonEncode({'action': action, 'apiKey': Config.apiKey, ...data});
    final r = await http.post(_u(), headers:_h(), body: body);
    try{ return jsonDecode(r.body) as Map<String,dynamic>; }catch(_){ return {'ok':false,'error':'bad_json'}; }
  }
  static Future listStores()=> call('list_stores',{});
  static Future startShift(String storeId, String user, String type)=> call('start_shift',{'storeId':storeId,'user':user,'shiftType':type});
  static Future endShift(String storeId, String user, String type)=> call('end_shift',{'storeId':storeId,'user':user,'shiftType':type});
  static Future zReport(String user,String storeId,String shift,double revenue,double expense,String comment)=>call('z_report',{'user':user,'storeId':storeId,'shift':shift,'revenue':revenue,'expense':expense,'comment':comment});
  static Future listEmployees({String? storeId})=> call('list_employees',{'storeId':storeId});
  static Future listStock({String? storeId})=> call('list_stock',{'storeId':storeId});
  static Future listRatings()=> call('list_ratings',{});
  static Future recordExpense(String user,String storeId,String title,double amount)=> call('expense',{'user':user,'storeId':storeId,'title':title,'amount':amount});
  static Future recordIncome(String user,String storeId,String vendor,double amount)=> call('income',{'user':user,'storeId':storeId,'vendor':vendor,'amount':amount});
}
