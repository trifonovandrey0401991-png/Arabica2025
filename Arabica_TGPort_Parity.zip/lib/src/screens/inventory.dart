
import 'package:flutter/material.dart';
import '../widgets/header.dart';
class InventoryScreen extends StatelessWidget {
  const InventoryScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: const Header('INVENTORYSCREEN'), body: const Center(child: Text('INVENTORYSCREEN', style: TextStyle(color: Colors.white, fontSize: 22))));
  }
}
