
import 'package:flutter/material.dart';
import '../widgets/header.dart';
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final tiles = <_Item>[
      _Item('Магазины', '/stores', Icons.store),
      _Item('Смена', '/shift', Icons.schedule),
      _Item('Z-отчёт', '/z', Icons.receipt_long),
      _Item('Расход', '/expenses', Icons.outbox),
      _Item('Приход', '/incomes', Icons.move_to_inbox),
      _Item('Остатки', '/stock', Icons.inventory_2),
      _Item('Инвентаризация', '/inventory', Icons.checklist),
      _Item('Отметка по QR', '/attendance_qr', Icons.qr_code_scanner),
      _Item('Фото-проверка', '/photo_flow', Icons.photo_camera),
      _Item('Анти-фрод', '/anti_fraud', Icons.verified_user),
      _Item('Рейтинг', '/ratings', Icons.emoji_events),
      _Item('Пользователи', '/users', Icons.group),
      _Item('Админ-панель', '/admin', Icons.security),
    ];
    return Scaffold(
      appBar: const Header('АРАБИКА'),
      body: GridView.count(
        crossAxisCount: 2, padding: const EdgeInsets.all(16), crossAxisSpacing: 12, mainAxisSpacing: 12,
        children: tiles.map((t)=> InkWell(
          onTap: ()=> Navigator.pushNamed(context, t.route),
          child: Card(color: const Color(0xFF111111), child: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(t.icon, color: Colors.white, size: 30),
            const SizedBox(height: 8),
            Text(t.title, style: const TextStyle(color: Colors.white)),
          ]))),
        )).toList(),
      ),
    );
  }
}
class _Item{ final String title; final String route; final IconData icon; _Item(this.title,this.route,this.icon); }
