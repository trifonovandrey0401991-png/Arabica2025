
import 'package:flutter/material.dart';
import '../widgets/header.dart';
class ZReportScreen extends StatelessWidget {
  const ZReportScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: const Header('ZREPORTSCREEN'), body: const Center(child: Text('ZREPORTSCREEN', style: TextStyle(color: Colors.white, fontSize: 22))));
  }
}
