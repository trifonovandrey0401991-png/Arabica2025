
class Config {
  static const backendUrl = 'https://script.google.com/macros/s/AKfycbxRA4QwUrxvtP3-NclT9GplFHkrVIp110Lu2uHOaGIlvvbZzW9kpUXdDoEijKgonGe7/exec';
  static const apiKey = 'Arabica2025_Vasilisa26122022';
}
