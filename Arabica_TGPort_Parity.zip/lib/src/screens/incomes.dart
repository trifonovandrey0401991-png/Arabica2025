
import 'package:flutter/material.dart';
import '../widgets/header.dart';
class IncomesScreen extends StatelessWidget {
  const IncomesScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: const Header('INCOMESSCREEN'), body: const Center(child: Text('INCOMESSCREEN', style: TextStyle(color: Colors.white, fontSize: 22))));
  }
}
