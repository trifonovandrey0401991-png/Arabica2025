
import 'package:flutter/material.dart';
import 'screens/splash.dart';
import 'screens/home.dart';
import 'screens/stores.dart';
import 'screens/shift.dart';
import 'screens/z_report.dart';
import 'screens/expenses.dart';
import 'screens/incomes.dart';
import 'screens/stock.dart';
import 'screens/inventory.dart';
import 'screens/att_qr.dart';
import 'screens/photo_flow.dart';
import 'screens/anti_fraud.dart';
import 'screens/ratings.dart';
import 'screens/admin_panel.dart';
import 'screens/users.dart';
class AppRouter {
  static Route onGenerateRoute(RouteSettings s){
    switch (s.name){
      case '/splash': return MaterialPageRoute(builder: (_)=>const SplashScreen());
      case '/': return MaterialPageRoute(builder: (_)=>const HomeScreen());
      case '/stores': return MaterialPageRoute(builder: (_)=>const StoresScreen());
      case '/shift': return MaterialPageRoute(builder: (_)=>const ShiftScreen());
      case '/z': return MaterialPageRoute(builder: (_)=>const ZReportScreen());
      case '/expenses': return MaterialPageRoute(builder: (_)=>const ExpensesScreen());
      case '/incomes': return MaterialPageRoute(builder: (_)=>const IncomesScreen());
      case '/stock': return MaterialPageRoute(builder: (_)=>const StockScreen());
      case '/inventory': return MaterialPageRoute(builder: (_)=>const InventoryScreen());
      case '/attendance_qr': return MaterialPageRoute(builder: (_)=>const AttendanceQrScreen());
      case '/photo_flow': return MaterialPageRoute(builder: (_)=>const PhotoFlowScreen());
      case '/anti_fraud': return MaterialPageRoute(builder: (_)=>const AntiFraudScreen());
      case '/ratings': return MaterialPageRoute(builder: (_)=>const RatingsScreen());
      case '/admin': return MaterialPageRoute(builder: (_)=>const AdminPanelScreen());
      case '/users': return MaterialPageRoute(builder: (_)=>const UsersScreen());
      default: return MaterialPageRoute(builder: (_)=>const HomeScreen());
    }
  }
}
